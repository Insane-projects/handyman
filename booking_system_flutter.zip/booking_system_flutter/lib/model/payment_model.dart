class PaymentClass {
  String? paymentMethod;
  int? paymentIndex;

  PaymentClass({this.paymentMethod, this.paymentIndex});
}
