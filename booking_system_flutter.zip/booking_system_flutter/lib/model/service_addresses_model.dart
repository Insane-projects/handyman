class ServiceAddressesModel {
  int? id;
  String? address;

  ServiceAddressesModel(this.id, this.address);
}
