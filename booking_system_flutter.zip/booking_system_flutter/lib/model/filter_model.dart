import 'package:flutter/material.dart';

class FilterModel {
  String? name;
  Widget? child;

  FilterModel({this.name, this.child});
}
