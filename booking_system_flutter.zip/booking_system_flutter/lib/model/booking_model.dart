class BookingModel {
  num? rate;
  num? discount;
  num? discountAmount;
  int? quantity;
  num? couponDiscount;
  num? couponDiscountAmount;
  num? totalAmount;
  String? type;

  BookingModel({this.rate, this.discount, this.discountAmount, this.quantity, this.couponDiscount, this.couponDiscountAmount, this.totalAmount, this.type});
}
